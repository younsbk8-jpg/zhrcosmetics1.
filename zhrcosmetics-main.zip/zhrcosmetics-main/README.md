# zhrcosmetics <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZHR Cosmetics - Natural Beauty Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 60px 20px;
        }
        header h1 {
            margin: 0;
            font-size: 4em; /* Made the name bigger for emphasis */
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 5px; /* Added spacing for a more prominent look */
        }
        header p {
            font-size: 1.5em;
            margin-top: 10px;
        }
        nav {
            background-color: #333;
            padding: 10px;
            text-align: center;
        }
        nav a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-weight: bold;
        }
        nav a:hover {
            color: #4CAF50;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .products {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
        .product {
            margin: 20px;
            text-align: center;
            width: 300px;
        }
        .product img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 10px;
        }
        .product h3 {
            color: #4CAF50;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>ZHR COSMETICS</h1>
        <p>Discover the Power of Natural Beauty</p>
    </header>
    
    <nav>
        <a href="#home">Home</a>
        <a href="#products">Products</a>
        <a href="#about">About Us</a>
        <a href="#contact">Contact</a>
    </nav>
    
    <div class="container">
        <section id="home">
            <h2>Welcome to ZHR Cosmetics</h2>
            <p>We specialize in high-quality, natural cosmetics made from organic ingredients like honey and olive oil. Our products are gentle on your skin and the environment.</p>
        </section>
        
        <section id="products">
            <h2>Our Natural Products</h2>
            <div class="products">
                <div class="product">
                    <img src="https://images.unsplash.com/photo-1546446078-93a8e3b7b7c5?w=300&h=250&fit=crop" alt="Natural Honey Product">
                    <h3>Honey Face Mask</h3>
                    <p>Nourishes and soothes with pure, organic honey for glowing skin.</p>
                </div>
                <div class="product">
                    <img src="https://images.unsplash.com/photo-1589924691995-400f5e0c5c5a?w=300&h=250&fit=crop" alt="Olive Oil Serum">
                    <h3>Olive Oil Serum</h3>
                    <p>Hydrates deeply with extra virgin olive oil and natural extracts.</p>
                </div>
                <div class="product">
                    <img src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300&h=250&fit=crop" alt="Honey and Olive Oil Blend">
                    <h3>Honey & Olive Oil Blend</h3>
                    <p>A luxurious mix for moisturizing and revitalizing your skin.</p>
                </div>
            </div>
        </section>
        
        <section id="about">
            <h2>About Us</h2>
            <p>ZHR Cosmetics was founded with a passion for sustainable beauty. All our products are cruelty-free and sourced from nature, featuring ingredients like honey and olive oil.</p>
        </section>
        
        <section id="contact">
            <h2>Contact Us</h2>
            <p>Email: info@zhrcosmetics.com | Phone: (123) 456-7890</p>
        </section>
    </div>
    
    <footer>
        <p>&copy; 2023 ZHR Cosmetics. All rights reserved.</p>
    </footer>
</body>
</html>
